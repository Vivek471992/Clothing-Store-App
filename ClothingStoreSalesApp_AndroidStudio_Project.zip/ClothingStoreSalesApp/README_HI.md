# Clothing Store Sales – Android App starter

यह Android Studio project है। Sales entries फोन के local Room/SQLite database में save होती हैं। Sales history app बंद/दोबारा खोलने के बाद भी बनी रहती है।

## APK बनाने के चरण

1. कंप्यूटर पर Android Studio (Hedgehog या नया) install करें।
2. इस ZIP को extract करें।
3. Android Studio में `ClothingStoreSalesApp` folder खोलें।
4. Gradle sync पूरा होने दें (पहली बार internet और SDK download की जरूरत होगी)।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
6. APK सामान्यतः `app/build/outputs/apk/debug/app-debug.apk` में बनेगा।
7. APK को अपने Android फोन में भेजकर install करें। फोन में “Install unknown apps” की अनुमति देनी पड़ सकती है।

## अभी शामिल सुविधाएँ

- Daily sales entry: date, staff, amount, bills, units, note
- Local phone database (Room / SQLite)
- Daily sales total, all-time sales, bills, units, target progress
- Sales history और entry delete
- Staff names और daily target fields

## अभी बाकी / अगला development phase

- Monthly report और date filters
- Staff-wise KPI ranking, attendance module
- Size/colour/article-wise stock and stock movement
- CSV/Excel export and local backup/restore
- Staff list and target settings ko database mein persist karna
- PIN lock and optional encrypted backup

## Data safety

Database app ke private storage mein hai. App uninstall karne ya app data clear karne par local records delete ho sakte hain. Isliye uninstall se pehle backup/export feature add karna zaroori hai. Is starter mein cloud sync nahi hai.

## Technical notes

- Package: `com.example.clothingstoresales`
- Min Android: Android 8.0 (API 26)
- Compile SDK: 35
- Kotlin + Jetpack Compose + Room
