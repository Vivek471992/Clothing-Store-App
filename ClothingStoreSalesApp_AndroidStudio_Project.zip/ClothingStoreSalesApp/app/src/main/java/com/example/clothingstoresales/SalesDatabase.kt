package com.example.clothingstoresales

import android.content.Context
import androidx.room.*

@Entity(tableName = "sales")
data class Sale(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleDate: String,
    val staffName: String,
    val amountPaise: Long,
    val bills: Int,
    val units: Int,
    val note: String = ""
)

@Dao
interface SalesDao {
    @Insert suspend fun insert(sale: Sale)
    @Delete suspend fun delete(sale: Sale)
    @Query("SELECT * FROM sales ORDER BY saleDate DESC, id DESC")
    suspend fun getAll(): List<Sale>
}

@Database(entities = [Sale::class], version = 1, exportSchema = false)
abstract class SalesDatabase : RoomDatabase() {
    abstract fun salesDao(): SalesDao

    companion object {
        @Volatile private var INSTANCE: SalesDatabase? = null
        fun get(context: Context): SalesDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    SalesDatabase::class.java,
                    "clothing_store_sales.db"
                ).build().also { INSTANCE = it }
            }
    }
}
