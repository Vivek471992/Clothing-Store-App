package com.example.clothingstoresales

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = SalesDatabase.get(this)
        setContent {
            MaterialTheme {
                SalesScreen(
                    loadSales = { db.salesDao().getAll() },
                    addSale = { db.salesDao().insert(it) },
                    deleteSale = { db.salesDao().delete(it) }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SalesScreen(
    loadSales: suspend () -> List<Sale>,
    addSale: suspend (Sale) -> Unit,
    deleteSale: suspend (Sale) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var sales by remember { mutableStateOf<List<Sale>>(emptyList()) }
    var staff by remember { mutableStateOf("Staff 1, Staff 2, Staff 3, Staff 4, Staff 5") }
    var selectedStaff by remember { mutableStateOf("Staff 1") }
    var date by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var amount by remember { mutableStateOf("") }
    var bills by remember { mutableStateOf("1") }
    var units by remember { mutableStateOf("1") }
    var note by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("150000") }
    var message by remember { mutableStateOf("") }

    fun refresh() { scope.launch { sales = loadSales() } }
    LaunchedEffect(Unit) { refresh() }

    val todaySales = sales.filter { it.saleDate == date }.sumOf { it.amountPaise } / 100.0
    val allSales = sales.sumOf { it.amountPaise } / 100.0
    val todayBills = sales.filter { it.saleDate == date }.sumOf { it.bills }
    val todayUnits = sales.filter { it.saleDate == date }.sumOf { it.units }
    val targetValue = target.toDoubleOrNull() ?: 0.0

    Scaffold(
        topBar = {
            TopAppBar(title = {
                Column {
                    Text("MY STORE SALES")
                    Text("Clothing Store Management", style = MaterialTheme.typography.labelSmall)
                }
            })
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card {
                    Column(Modifier.padding(16.dp)) {
                        Text("Sales stored on this phone", style = MaterialTheme.typography.titleMedium)
                        Text("No account or internet connection required for local records.")
                        Spacer(Modifier.height(12.dp))
                        Text("Today's sales: ₹${"%,.2f".format(Locale("en", "IN"), todaySales)}")
                        Text("All-time recorded sales: ₹${"%,.2f".format(Locale("en", "IN"), allSales)}")
                        Text("Bills: $todayBills   •   Units: $todayUnits")
                        val achievement = if (targetValue > 0) todaySales / targetValue else 0.0
                        LinearProgressIndicator(
                            progress = { achievement.coerceIn(0.0, 1.0).toFloat() },
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                        )
                        Text("Target achievement: ${"%.1f".format(achievement * 100)}%")
                    }
                }
            }
            item {
                Text("Add sales entry", style = MaterialTheme.typography.titleLarge)
                OutlinedTextField(date, { date = it }, label = { Text("Date (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth())
                val staffOptions = staff.split(",").map { it.trim() }.filter { it.isNotBlank() }
                var expanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                    OutlinedTextField(
                        value = selectedStaff,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Staff member") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        staffOptions.forEach { name ->
                            DropdownMenuItem(text = { Text(name) }, onClick = {
                                selectedStaff = name
                                expanded = false
                            })
                        }
                    }
                }
                OutlinedTextField(amount, { amount = it }, label = { Text("Sales amount (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(bills, { bills = it }, label = { Text("Bills") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                    OutlinedTextField(units, { units = it }, label = { Text("Units") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                }
                OutlinedTextField(note, { note = it }, label = { Text("Note (optional)") }, modifier = Modifier.fillMaxWidth())
                Button(
                    onClick = {
                        val a = amount.toDoubleOrNull()
                        val b = bills.toIntOrNull()
                        val u = units.toIntOrNull()
                        if (a == null || a <= 0 || b == null || b <= 0 || u == null || u <= 0 ||
                            !date.matches(Regex("\\\\d{4}-\\\\d{2}-\\\\d{2}"))) {
                            message = "Please enter a valid date, amount, bills and units."
                        } else {
                            scope.launch {
                                addSale(Sale(
                                    saleDate = date,
                                    staffName = selectedStaff,
                                    amountPaise = (a * 100).toLong(),
                                    bills = b,
                                    units = u,
                                    note = note
                                ))
                                amount = ""; bills = "1"; units = "1"; note = ""
                                message = "Sales entry saved on this phone."
                                refresh()
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Save sales entry") }
                if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.primary)
            }
            item {
                Text("Store settings", style = MaterialTheme.typography.titleLarge)
                OutlinedTextField(target, { target = it }, label = { Text("Daily target (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(staff, { staff = it }, label = { Text("Staff names (comma separated)") }, modifier = Modifier.fillMaxWidth())
                Text("Staff list setting is currently held for this app session. Sales entries are stored in the phone's local database.")
            }
            item { Text("Sales history", style = MaterialTheme.typography.titleLarge) }
            items(sales, key = { it.id }) { sale ->
                Card {
                    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(sale.staffName, style = MaterialTheme.typography.titleMedium)
                            Text("${sale.saleDate} • ${sale.bills} bills • ${sale.units} units")
                            if (sale.note.isNotBlank()) Text(sale.note)
                            Text("ATV: ₹${"%.2f".format(sale.amountPaise / 100.0 / sale.bills)}")
                        }
                        Column {
                            Text("₹${"%.2f".format(sale.amountPaise / 100.0)}")
                            TextButton(onClick = { scope.launch { deleteSale(sale); refresh() } }) { Text("Delete") }
                        }
                    }
                }
            }
        }
    }
}
