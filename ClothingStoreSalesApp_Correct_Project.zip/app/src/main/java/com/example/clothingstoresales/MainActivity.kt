package com.example.clothingstoresales

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.KeyboardType
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = SalesDatabase.get(this).salesDao()
        setContent { MaterialTheme { SalesScreen(dao) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SalesScreen(dao: SalesDao) {
    val scope = rememberCoroutineScope()
    val sales by dao.observeAll().collectAsState(initial = emptyList())
    val total by dao.observeTotal().collectAsState(initial = 0.0)
    var staff by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var bills by remember { mutableStateOf("1") }
    var units by remember { mutableStateOf("1") }
    var note by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("150000") }
    val today = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) }
    val todayTotal = sales.filter { it.date == today }.sumOf { it.amount }

    Scaffold(topBar = { TopAppBar(title = { Text("Clothing Store Sales") }) }) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card {
                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                        Text("Today's Sales", style = MaterialTheme.typography.titleMedium)
                        Text("₹%.2f".format(todayTotal), style = MaterialTheme.typography.headlineMedium)
                        Text("All-time Sales: ₹%.2f".format(total))
                        OutlinedTextField(
                            value = target, onValueChange = { target = it },
                            label = { Text("Daily target (₹)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth()
                        )
                        val targetValue = target.toDoubleOrNull() ?: 0.0
                        val progress = if (targetValue > 0) (todayTotal / targetValue).toFloat().coerceIn(0f, 1f) else 0f
                        LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
            item { Text("Add Sale", style = MaterialTheme.typography.titleLarge) }
            item {
                OutlinedTextField(staff, { staff = it }, label = { Text("Staff name") }, modifier = Modifier.fillMaxWidth())
            }
            item {
                OutlinedTextField(amount, { amount = it }, label = { Text("Sale amount (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(bills, { bills = it }, label = { Text("Bills") }, modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(units, { units = it }, label = { Text("Units") }, modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                }
            }
            item { OutlinedTextField(note, { note = it }, label = { Text("Note (optional)") }, modifier = Modifier.fillMaxWidth()) }
            item {
                Button(
                    onClick = {
                        val value = amount.toDoubleOrNull()
                        if (staff.isNotBlank() && value != null && value > 0) {
                            scope.launch {
                                dao.insert(Sale(date = today, staff = staff.trim(), amount = value,
                                    bills = bills.toIntOrNull() ?: 1, units = units.toIntOrNull() ?: 1, note = note.trim()))
                                amount = ""; bills = "1"; units = "1"; note = ""
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Save Sale") }
            }
            item { Text("Sales History", style = MaterialTheme.typography.titleLarge) }
            if (sales.isEmpty()) item { Text("No sales entered yet.") }
            items(sales, key = { it.id }) { sale ->
                Card {
                    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(sale.staff, style = MaterialTheme.typography.titleMedium)
                            Text("${sale.date} • ${sale.bills} bills • ${sale.units} units")
                            Text("₹%.2f".format(sale.amount))
                            if (sale.note.isNotBlank()) Text(sale.note)
                        }
                        TextButton(onClick = { scope.launch { dao.delete(sale.id) } }) { Text("Delete") }
                    }
                }
            }
            item { Text("Data is stored on this phone. Uninstalling the app or clearing its data may erase it.") }
        }
    }
}
