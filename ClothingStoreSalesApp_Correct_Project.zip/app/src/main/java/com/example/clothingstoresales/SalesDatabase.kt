package com.example.clothingstoresales

import android.content.Context
import androidx.room.Database
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "sales")
data class Sale(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,
    val staff: String,
    val amount: Double,
    val bills: Int,
    val units: Int,
    val note: String = ""
)

@Dao
interface SalesDao {
    @Insert suspend fun insert(sale: Sale)
    @Query("SELECT * FROM sales ORDER BY id DESC")
    fun observeAll(): Flow<List<Sale>>
    @Query("DELETE FROM sales WHERE id = :id")
    suspend fun delete(id: Long)
    @Query("SELECT COALESCE(SUM(amount), 0) FROM sales")
    fun observeTotal(): Flow<Double>
}

@Database(entities = [Sale::class], version = 1, exportSchema = false)
abstract class SalesDatabase : RoomDatabase() {
    abstract fun salesDao(): SalesDao

    companion object {
        @Volatile private var INSTANCE: SalesDatabase? = null
        fun get(context: Context): SalesDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    SalesDatabase::class.java,
                    "clothing_store_sales.db"
                ).build().also { INSTANCE = it }
            }
    }
}
