# Clothing Store Sales App

यह Android app बिना PIN के सीधे खुलेगा। Sales entries Room/SQLite database में फोन पर save होती हैं।

## Features in this starter build
- Staff name के साथ sale entry
- Amount, bills, units और optional note
- आज की sales और all-time sales
- Daily target और progress bar
- Sales history और entry delete

## Build requirements
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- JDK 17
- Android SDK 35
- Minimum Android 8.0 (API 26)

यह source project है, APK नहीं। APK GitHub Actions से build किया जा सकता है।
डेटा app के private local database में रहता है; uninstall/clear data करने पर हट सकता है।
